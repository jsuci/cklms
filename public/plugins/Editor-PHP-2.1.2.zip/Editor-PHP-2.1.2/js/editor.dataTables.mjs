/*! DataTables styling integration for DataTables' Editor
 * ©SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-dt';
import Editor from 'datatables.net-editor';

var Editor = DataTable.Editor;


export default Editor;
